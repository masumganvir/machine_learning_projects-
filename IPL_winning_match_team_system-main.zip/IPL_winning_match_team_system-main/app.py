import os
import pickle
import numpy as np
import pandas as pd
from flask import Flask, render_template, request, jsonify

app = Flask(__name__)

# Load model pipeline with fallback
MODEL_PATH = os.path.join(os.path.dirname(__file__), 'pipe.pkl')
try:
    with open(MODEL_PATH, 'rb') as f:
        pipe = pickle.load(f)
    print("[INFO] Model pipe.pkl successfully loaded!")
except Exception as e:
    print(f"[WARNING] Error loading pre-packaged model ({e}). Attempting fallback training...")
    try:
        from train_model import train_and_export_model
        pipe = train_and_export_model(output_pickle=MODEL_PATH)
        print("[INFO] Model successfully trained and loaded on startup!")
    except Exception as te:
        print(f"[ERROR] Auto-training fallback also failed: {te}")
        pipe = None

@app.after_request
def add_cors_headers(response):
    """Enable CORS for external clients or separated frontend deployments."""
    response.headers['Access-Control-Allow-Origin'] = '*'
    response.headers['Access-Control-Allow-Headers'] = 'Content-Type,Authorization'
    response.headers['Access-Control-Allow-Methods'] = 'GET,POST,OPTIONS'
    return response

TEAMS_META = [
    {
        "name": "Chennai Super Kings",
        "short": "CSK",
        "primary": "#fdb913",
        "secondary": "#0081e8",
        "accent": "#ffd83b",
        "icon": "🦁"
    },
    {
        "name": "Mumbai Indians",
        "short": "MI",
        "primary": "#004ba0",
        "secondary": "#d1ab3e",
        "accent": "#0077ff",
        "icon": "🌀"
    },
    {
        "name": "Royal Challengers Bangalore",
        "short": "RCB",
        "primary": "#d1171c",
        "secondary": "#2b2a29",
        "accent": "#e63946",
        "icon": "👑"
    },
    {
        "name": "Kolkata Knight Riders",
        "short": "KKR",
        "primary": "#3a225d",
        "secondary": "#b3995d",
        "accent": "#7b2cbf",
        "icon": "⚔️"
    },
    {
        "name": "Sunrisers Hyderabad",
        "short": "SRH",
        "primary": "#ff822a",
        "secondary": "#000000",
        "accent": "#ff9f1c",
        "icon": "🦅"
    },
    {
        "name": "Rajasthan Royals",
        "short": "RR",
        "primary": "#ea1a85",
        "secondary": "#254aa5",
        "accent": "#ff4d94",
        "icon": "👑"
    },
    {
        "name": "Delhi Capitals",
        "short": "DC",
        "primary": "#004c93",
        "secondary": "#b9251c",
        "accent": "#00a6fb",
        "icon": "🐅"
    },
    {
        "name": "Kings XI Punjab",
        "short": "KXIP",
        "primary": "#ed1b24",
        "secondary": "#b0c4de",
        "accent": "#ff4d6d",
        "icon": "🦁"
    }
]

CITIES = [
    "Ahmedabad", "Bangalore", "Bengaluru", "Chennai", "Delhi",
    "Hyderabad", "Jaipur", "Kolkata", "Mohali", "Mumbai",
    "Pune", "Visakhapatnam", "Chandigarh", "Dharamsala", "Cuttack",
    "Indore", "Nagpur", "Raipur", "Ranchi", "Abu Dhabi", "Sharjah",
    "Cape Town", "Durban", "Centurion", "Johannesburg", "Port Elizabeth"
]

@app.route('/')
def home():
    return render_template('index.html', teams=TEAMS_META, cities=CITIES)

@app.route('/api/meta', methods=['GET'])
def get_meta():
    return jsonify({
        "status": "success",
        "teams": TEAMS_META,
        "cities": sorted(CITIES)
    })

@app.route('/api/health', methods=['GET'])
def health():
    return jsonify({
        "status": "healthy",
        "service": "ipl-win-probability-predictor",
        "model_loaded": pipe is not None
    })

@app.route('/api/predict', methods=['POST'])
def predict():
    if pipe is None:
        return jsonify({"status": "error", "message": "Model not loaded on server."}), 500

    try:
        data = request.get_json(force=True)
        batting_team = data.get('batting_team')
        bowling_team = data.get('bowling_team')
        city = data.get('city')
        target = float(data.get('target', 0))
        score = float(data.get('score', 0))
        overs = float(data.get('overs', 0))
        wickets = float(data.get('wickets', 0))

        # Basic validations
        if not batting_team or not bowling_team or not city:
            return jsonify({"status": "error", "message": "Missing team or city selection."}), 400

        if batting_team == bowling_team:
            return jsonify({"status": "error", "message": "Batting and bowling teams must be different."}), 400

        if target <= 0:
            return jsonify({"status": "error", "message": "Target must be greater than 0."}), 400

        # Calculate balls bowled
        whole_overs = int(overs)
        balls_in_over = int(round((overs - whole_overs) * 10))
        if balls_in_over >= 6:
            balls_bowled = int(round(overs * 6))
        else:
            balls_bowled = whole_overs * 6 + balls_in_over

        if balls_bowled <= 0:
            balls_bowled = 1
        if balls_bowled > 120:
            balls_bowled = 120

        balls_left = 120 - balls_bowled
        runs_left = target - score
        wickets_remaining = max(0, 10 - int(wickets))

        # Immediate result conditions
        if score >= target:
            return jsonify({
                "status": "success",
                "batting_team": batting_team,
                "bowling_team": bowling_team,
                "win_probability": 100.0,
                "loss_probability": 0.0,
                "runs_left": 0,
                "balls_left": balls_left,
                "wickets_remaining": wickets_remaining,
                "crr": round((score * 6) / balls_bowled, 2),
                "rrr": 0.0,
                "momentum": "Match Won!",
                "summary": f"{batting_team} has chased down the target successfully!"
            })

        if wickets_remaining <= 0 or (balls_left <= 0 and score < target):
            return jsonify({
                "status": "success",
                "batting_team": batting_team,
                "bowling_team": bowling_team,
                "win_probability": 0.0,
                "loss_probability": 100.0,
                "runs_left": max(0, int(runs_left)),
                "balls_left": 0,
                "wickets_remaining": 0,
                "crr": round((score * 6) / balls_bowled, 2),
                "rrr": 99.9,
                "momentum": "Match Conceded!",
                "summary": f"{bowling_team} has won by defending the total!"
            })

        crr = (score * 6) / balls_bowled
        safe_balls_left = max(1, balls_left)
        rrr = (runs_left * 6) / safe_balls_left

        input_df = pd.DataFrame([{
            'batting_team': batting_team,
            'bowling_team': bowling_team,
            'city': city,
            'runs_left': runs_left,
            'balls_left': safe_balls_left,
            'wickets': wickets_remaining,
            'total_runs_x': target,
            'crr': crr,
            'rrr': rrr
        }])

        result = pipe.predict_proba(input_df)
        loss_prob = float(result[0][0])
        win_prob = float(result[0][1])

        # Clamp between 0.1% and 99.9% for ongoing match
        win_pct = round(max(0.1, min(99.9, win_prob * 100)), 1)
        loss_pct = round(100.0 - win_pct, 1)

        # Match Momentum evaluation
        if win_pct >= 75:
            momentum = f"Strong Advantage: {batting_team}"
        elif win_pct >= 55:
            momentum = f"Moderate Advantage: {batting_team}"
        elif win_pct >= 45:
            momentum = "Tough Contest: 50-50 Knife-Edge"
        elif win_pct >= 25:
            momentum = f"Moderate Advantage: {bowling_team}"
        else:
            momentum = f"Commanding Position: {bowling_team}"

        summary = (
            f"{batting_team} needs {int(runs_left)} runs from {balls_left} balls "
            f"with {wickets_remaining} wickets in hand (RRR: {round(rrr, 2)} vs CRR: {round(crr, 2)})."
        )

        return jsonify({
            "status": "success",
            "batting_team": batting_team,
            "bowling_team": bowling_team,
            "city": city,
            "target": target,
            "score": score,
            "overs": overs,
            "wickets": wickets,
            "runs_left": int(runs_left),
            "balls_left": balls_left,
            "wickets_remaining": wickets_remaining,
            "crr": round(crr, 2),
            "rrr": round(rrr, 2),
            "win_probability": win_pct,
            "loss_probability": loss_pct,
            "momentum": momentum,
            "summary": summary
        })

    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500

@app.route('/api/progression', methods=['POST'])
def progression():
    """Simulate projected over-by-over probability timeline."""
    if pipe is None:
        return jsonify({"status": "error", "message": "Model not loaded."}), 500

    try:
        data = request.get_json(force=True)
        batting_team = data.get('batting_team')
        bowling_team = data.get('bowling_team')
        city = data.get('city')
        target = float(data.get('target', 180))
        current_overs = int(float(data.get('overs', 10)))
        current_score = float(data.get('score', 90))
        current_wickets = int(float(data.get('wickets', 2)))

        timeline = []
        # Generate simulated progression from over 1 to 20
        # Interpolate score from start up to current, then extrapolate
        for over in range(1, 21):
            if over <= current_overs:
                fraction = over / max(1, current_overs)
                sim_score = int(current_score * fraction)
                sim_w = min(10, int(current_wickets * fraction))
            else:
                remaining_overs = 20 - current_overs
                overs_past = over - current_overs
                projected_rate = max(6.0, current_score / max(1, current_overs))
                sim_score = int(current_score + (overs_past * projected_rate))
                sim_w = min(9, current_wickets + (overs_past // 3))

            balls_left = max(1, (20 - over) * 6)
            runs_left = max(0, target - sim_score)
            w_left = max(1, 10 - sim_w)
            crr = (sim_score * 6) / max(1, over * 6)
            rrr = (runs_left * 6) / balls_left

            df = pd.DataFrame([{
                'batting_team': batting_team,
                'bowling_team': bowling_team,
                'city': city,
                'runs_left': runs_left,
                'balls_left': balls_left,
                'wickets': w_left,
                'total_runs_x': target,
                'crr': crr,
                'rrr': rrr
            }])

            p = pipe.predict_proba(df)[0]
            win_p = round(float(p[1]) * 100, 1)

            timeline.append({
                "over": over,
                "projected_score": sim_score,
                "wickets": sim_w,
                "win_probability": win_p,
                "loss_probability": round(100.0 - win_p, 1)
            })

        return jsonify({
            "status": "success",
            "timeline": timeline
        })
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500

if __name__ == '__main__':
    port = int(os.environ.get('PORT', 5000))
    # Production vs Dev check
    debug = os.environ.get('FLASK_DEBUG', 'False').lower() == 'true'
    print(f"[INFO] Starting IPL Win Predictor Server on port {port}...")
    app.run(host='0.0.0.0', port=port, debug=debug)