/**
 * IPL Win Probability Predictor - Interactive Match Engine
 */

document.addEventListener('DOMContentLoaded', () => {
  // DOM Elements
  const battingSelect = document.getElementById('battingTeam');
  const bowlingSelect = document.getElementById('bowlingTeam');
  const citySelect = document.getElementById('matchCity');
  const targetInput = document.getElementById('targetScore');
  const scoreInput = document.getElementById('currentScore');
  const oversSlider = document.getElementById('oversRange');
  const oversBadge = document.getElementById('oversBadge');
  const wicketsInput = document.getElementById('wicketsInput');
  const wicketsPills = document.querySelectorAll('.wicket-pill');
  const predictBtn = document.getElementById('predictBtn');

  // Math Tickers
  const calcRunsNeeded = document.getElementById('calcRunsNeeded');
  const calcBallsLeft = document.getElementById('calcBallsLeft');
  const calcCRR = document.getElementById('calcCRR');
  const calcRRR = document.getElementById('calcRRR');

  // Gauges & Outputs
  const battingCircle = document.getElementById('battingCircle');
  const bowlingCircle = document.getElementById('bowlingCircle');
  const battingPct = document.getElementById('battingPct');
  const bowlingPct = document.getElementById('bowlingPct');
  const battingTeamLabel = document.getElementById('battingTeamLabel');
  const bowlingTeamLabel = document.getElementById('bowlingTeamLabel');
  const battingTeamIcon = document.getElementById('battingTeamIcon');
  const bowlingTeamIcon = document.getElementById('bowlingTeamIcon');
  const momentumBadge = document.getElementById('momentumBadge');

  // Tug of war
  const tugBatLabel = document.getElementById('tugBatLabel');
  const tugBowlLabel = document.getElementById('tugBowlLabel');
  const tugFillLeft = document.getElementById('tugFillLeft');
  const tugFillRight = document.getElementById('tugFillRight');
  const tugPin = document.getElementById('tugPin');

  // Intel Summary
  const matchSummaryText = document.getElementById('matchSummaryText');
  const wicketsInHandVal = document.getElementById('wicketsInHandVal');
  const rateDeltaVal = document.getElementById('rateDeltaVal');
  const pressureVal = document.getElementById('pressureVal');
  const progressionSvg = document.getElementById('progressionSvg');

  // Team metadata dictionary for quick styling
  const TEAMS_LOOKUP = {
    "Chennai Super Kings": { short: "CSK", color: "#fdb913", glow: "rgba(253, 185, 19, 0.4)", icon: "🦁" },
    "Mumbai Indians": { short: "MI", color: "#004ba0", glow: "rgba(0, 119, 255, 0.4)", icon: "🌀" },
    "Royal Challengers Bangalore": { short: "RCB", color: "#d1171c", glow: "rgba(209, 23, 28, 0.4)", icon: "👑" },
    "Kolkata Knight Riders": { short: "KKR", color: "#6a0dad", glow: "rgba(106, 13, 173, 0.4)", icon: "⚔️" },
    "Sunrisers Hyderabad": { short: "SRH", color: "#ff822a", glow: "rgba(255, 130, 42, 0.4)", icon: "🦅" },
    "Rajasthan Royals": { short: "RR", color: "#ea1a85", glow: "rgba(234, 26, 133, 0.4)", icon: "👑" },
    "Delhi Capitals": { short: "DC", color: "#0077b6", glow: "rgba(0, 119, 182, 0.4)", icon: "🐅" },
    "Kings XI Punjab": { short: "KXIP", color: "#ed1b24", glow: "rgba(237, 27, 36, 0.4)", icon: "🦁" }
  };

  // Scenario Presets Dictionary
  const SCENARIOS = {
    final2019: {
      batting: "Chennai Super Kings",
      bowling: "Mumbai Indians",
      city: "Hyderabad",
      target: 150,
      score: 141,
      overs: 19.0,
      wickets: 5
    },
    elclassico: {
      batting: "Mumbai Indians",
      bowling: "Chennai Super Kings",
      city: "Mumbai",
      target: 180,
      score: 135,
      overs: 15.0,
      wickets: 3
    },
    chinnaswamy: {
      batting: "Royal Challengers Bangalore",
      bowling: "Kolkata Knight Riders",
      city: "Bengaluru",
      target: 205,
      score: 110,
      overs: 11.2,
      wickets: 2
    },
    srhdefense: {
      batting: "Delhi Capitals",
      bowling: "Sunrisers Hyderabad",
      city: "Hyderabad",
      target: 145,
      score: 88,
      overs: 14.0,
      wickets: 6
    }
  };

  // State
  let currentBatPct = 50;
  let currentBowlPct = 50;

  // Initialize
  function init() {
    updateThemeColors();
    updateLiveTickers();
    bindEvents();
    // Run initial prediction for default state
    runPrediction();
  }

  function bindEvents() {
    battingSelect.addEventListener('change', () => {
      validateOpponentSelection('batting');
      updateThemeColors();
      updateLiveTickers();
    });

    bowlingSelect.addEventListener('change', () => {
      validateOpponentSelection('bowling');
      updateThemeColors();
      updateLiveTickers();
    });

    citySelect.addEventListener('change', updateLiveTickers);

    targetInput.addEventListener('input', updateLiveTickers);
    scoreInput.addEventListener('input', updateLiveTickers);

    oversSlider.addEventListener('input', (e) => {
      const val = parseFloat(e.target.value).toFixed(1);
      const whole = Math.floor(val);
      const ballPart = Math.round((val - whole) * 10);
      const totalBalls = whole * 6 + (ballPart >= 6 ? 6 : ballPart);
      oversBadge.textContent = `${val} ov (${totalBalls} balls)`;
      updateLiveTickers();
    });

    wicketsPills.forEach(pill => {
      pill.addEventListener('click', () => {
        wicketsPills.forEach(p => p.classList.remove('active'));
        pill.classList.add('active');
        wicketsInput.value = pill.getAttribute('data-wicket');
        updateLiveTickers();
      });
    });

    predictBtn.addEventListener('click', runPrediction);

    // Scenario preset buttons
    document.querySelectorAll('.scenario-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        const key = btn.getAttribute('data-scenario');
        if (SCENARIOS[key]) {
          loadScenario(SCENARIOS[key]);
        }
      });
    });
  }

  // Prevent same team selection
  function validateOpponentSelection(changedRole) {
    if (battingSelect.value === bowlingSelect.value) {
      const teams = Object.keys(TEAMS_LOOKUP);
      for (const t of teams) {
        if (t !== battingSelect.value) {
          if (changedRole === 'batting') {
            bowlingSelect.value = t;
          } else {
            battingSelect.value = t;
          }
          break;
        }
      }
    }
  }

  // Update Dynamic Stadium Theme Colors
  function updateThemeColors() {
    const batTeam = battingSelect.value;
    const bowlTeam = bowlingSelect.value;

    const batMeta = TEAMS_LOOKUP[batTeam] || { short: "BAT", color: "#0077ff", glow: "rgba(0,119,255,0.4)", icon: "🏏" };
    const bowlMeta = TEAMS_LOOKUP[bowlTeam] || { short: "BOWL", color: "#fdb913", glow: "rgba(253,185,19,0.4)", icon: "🛡️" };

    document.documentElement.style.setProperty('--bat-color', batMeta.color);
    document.documentElement.style.setProperty('--bat-glow', batMeta.glow);
    document.documentElement.style.setProperty('--bowl-color', bowlMeta.color);
    document.documentElement.style.setProperty('--bowl-glow', bowlMeta.glow);

    // Update Team Display Badges
    document.getElementById('battingCrest').textContent = batMeta.icon;
    document.getElementById('battingAbbr').textContent = batMeta.short;
    document.getElementById('bowlingCrest').textContent = bowlMeta.icon;
    document.getElementById('bowlingAbbr').textContent = bowlMeta.short;

    battingTeamLabel.textContent = batTeam;
    bowlingTeamLabel.textContent = bowlTeam;
    battingTeamIcon.textContent = batMeta.icon;
    bowlingTeamIcon.textContent = bowlMeta.icon;
  }

  // Real-Time Math Ticker updates
  function updateLiveTickers() {
    const target = parseFloat(targetInput.value) || 0;
    const score = parseFloat(scoreInput.value) || 0;
    const overs = parseFloat(oversSlider.value) || 0;
    const wickets = parseInt(wicketsInput.value) || 0;

    const wholeOvers = Math.floor(overs);
    const ballsInOver = Math.round((overs - wholeOvers) * 10);
    const ballsBowled = ballsInOver >= 6 ? Math.round(overs * 6) : (wholeOvers * 6 + ballsInOver);

    const safeBallsBowled = Math.max(1, ballsBowled);
    const ballsLeft = Math.max(0, 120 - safeBallsBowled);
    const runsLeft = target - score;
    const wicketsInHand = Math.max(0, 10 - wickets);

    const crr = (score * 6) / safeBallsBowled;
    const rrr = ballsLeft > 0 ? (runsLeft * 6) / ballsLeft : 99.9;

    calcRunsNeeded.textContent = runsLeft > 0 ? runsLeft : 0;
    calcBallsLeft.textContent = ballsLeft;
    calcCRR.textContent = crr.toFixed(2);
    calcRRR.textContent = rrr >= 0 ? rrr.toFixed(2) : "0.00";
    wicketsInHandVal.textContent = wicketsInHand;

    const delta = (rrr - crr).toFixed(2);
    rateDeltaVal.textContent = (delta > 0 ? `+${delta}` : delta);

    if (rrr > 13) {
      pressureVal.textContent = "Extreme (13+)";
      pressureVal.style.color = "#ff3366";
    } else if (rrr > 9.5) {
      pressureVal.textContent = "High Pressure";
      pressureVal.style.color = "#ff822a";
    } else if (rrr > 7.5) {
      pressureVal.textContent = "Moderate";
      pressureVal.style.color = "#fdb913";
    } else {
      pressureVal.textContent = "Comfortable";
      pressureVal.style.color = "#00f59b";
    }
  }

  // Load a preset scenario
  function loadScenario(scenario) {
    battingSelect.value = scenario.batting;
    bowlingSelect.value = scenario.bowling;
    validateOpponentSelection('batting');
    citySelect.value = scenario.city;
    targetInput.value = scenario.target;
    scoreInput.value = scenario.score;
    oversSlider.value = scenario.overs;

    const whole = Math.floor(scenario.overs);
    const ballPart = Math.round((scenario.overs - whole) * 10);
    const totalBalls = whole * 6 + (ballPart >= 6 ? 6 : ballPart);
    oversBadge.textContent = `${scenario.overs.toFixed(1)} ov (${totalBalls} balls)`;

    wicketsPills.forEach(pill => {
      if (parseInt(pill.getAttribute('data-wicket')) === scenario.wickets) {
        pill.classList.add('active');
      } else {
        pill.classList.remove('active');
      }
    });
    wicketsInput.value = scenario.wickets;

    updateThemeColors();
    updateLiveTickers();
    runPrediction();
  }

  // Main Prediction API Caller
  async function runPrediction() {
    const payload = {
      batting_team: battingSelect.value,
      bowling_team: bowlingSelect.value,
      city: citySelect.value,
      target: parseFloat(targetInput.value),
      score: parseFloat(scoreInput.value),
      overs: parseFloat(oversSlider.value),
      wickets: parseInt(wicketsInput.value)
    };

    // Button animation state
    predictBtn.style.opacity = '0.7';
    predictBtn.querySelector('.btn-text').textContent = "CALCULATING PROBABILITY...";

    try {
      const response = await fetch('/api/predict', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });

      const data = await response.json();
      if (data.status === 'success') {
        renderPredictionResults(data);
        fetchProgression(payload);
      } else {
        alert("Prediction Error: " + (data.message || "Failed to calculate"));
      }
    } catch (err) {
      console.error("Fetch error:", err);
    } finally {
      predictBtn.style.opacity = '1';
      predictBtn.querySelector('.btn-text').textContent = "CALCULATE WIN PROBABILITY";
    }
  }

  // Render probability gauges and tug of war
  function renderPredictionResults(data) {
    const win = data.win_probability;
    const loss = data.loss_probability;

    // Animate radial gauges (SVG circumference = 2 * PI * 58 ≈ 364.4)
    const circumference = 364.4;
    const batOffset = circumference - (circumference * win / 100);
    const bowlOffset = circumference - (circumference * loss / 100);

    battingCircle.style.strokeDashoffset = batOffset;
    bowlingCircle.style.strokeDashoffset = bowlOffset;

    // Animated counter numbers
    animateValue(battingPct, currentBatPct, win, 800, "%");
    animateValue(bowlingPct, currentBowlPct, loss, 800, "%");
    currentBatPct = win;
    currentBowlPct = loss;

    // Tug-of-war Bar
    tugFillLeft.style.width = `${win}%`;
    tugFillRight.style.width = `${loss}%`;
    tugPin.style.left = `${win}%`;

    const batShort = (TEAMS_LOOKUP[data.batting_team] || {}).short || "BAT";
    const bowlShort = (TEAMS_LOOKUP[data.bowling_team] || {}).short || "BOWL";
    tugBatLabel.textContent = `${batShort}: ${win}%`;
    tugBowlLabel.textContent = `${bowlShort}: ${loss}%`;

    // Momentum badge
    momentumBadge.textContent = data.momentum;
    if (win >= 70) {
      momentumBadge.style.borderColor = "var(--bat-color)";
      momentumBadge.style.color = "#00f59b";
      momentumBadge.style.background = "rgba(0, 245, 155, 0.1)";
    } else if (win <= 30) {
      momentumBadge.style.borderColor = "var(--bowl-color)";
      momentumBadge.style.color = "#ff3366";
      momentumBadge.style.background = "rgba(255, 51, 102, 0.1)";
    } else {
      momentumBadge.style.borderColor = "#fdb913";
      momentumBadge.style.color = "#fdb913";
      momentumBadge.style.background = "rgba(253, 185, 19, 0.1)";
    }

    // Match Intelligence text
    matchSummaryText.textContent = data.summary;
  }

  // Smooth number interpolation
  function animateValue(elem, start, end, duration, suffix = "") {
    const startTime = performance.now();
    function update(time) {
      const elapsed = time - startTime;
      const progress = Math.min(elapsed / duration, 1);
      // Ease out cubic
      const ease = 1 - Math.pow(1 - progress, 3);
      const current = (start + (end - start) * ease).toFixed(1);
      elem.textContent = current + suffix;
      if (progress < 1) {
        requestAnimationFrame(update);
      }
    }
    requestAnimationFrame(update);
  }

  // Fetch and draw SVG progression curve
  async function fetchProgression(payload) {
    try {
      const res = await fetch('/api/progression', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      const data = await res.json();
      if (data.status === 'success' && data.timeline) {
        renderProgressionSvg(data.timeline);
      }
    } catch (e) {
      console.error("Progression fetch error:", e);
    }
  }

  // Render SVG Smooth Line Chart
  function renderProgressionSvg(timeline) {
    if (!progressionSvg || timeline.length === 0) return;

    const width = 500;
    const height = 130;
    const padding = 20;

    const innerW = width - (padding * 2);
    const innerH = height - (padding * 2);

    // Map overs (1 to 20) and probability (0 to 100) to coordinates
    const points = timeline.map((pt, idx) => {
      const x = padding + (idx / (timeline.length - 1)) * innerW;
      const y = height - padding - (pt.win_probability / 100) * innerH;
      return { x, y, ...pt };
    });

    // Create smooth SVG path
    let pathD = `M ${points[0].x},${points[0].y}`;
    for (let i = 0; i < points.length - 1; i++) {
      const p0 = points[i];
      const p1 = points[i + 1];
      const cpX = (p0.x + p1.x) / 2;
      pathD += ` C ${cpX},${p0.y} ${cpX},${p1.y} ${p1.x},${p1.y}`;
    }

    // Gradient fill path
    const areaD = `${pathD} L ${points[points.length - 1].x},${height - padding} L ${points[0].x},${height - padding} Z`;

    const batColor = getComputedStyle(document.documentElement).getPropertyValue('--bat-color').trim() || '#00e5ff';

    progressionSvg.innerHTML = `
      <defs>
        <linearGradient id="chartGradient" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stop-color="${batColor}" stop-opacity="0.35"/>
          <stop offset="100%" stop-color="${batColor}" stop-opacity="0.0"/>
        </linearGradient>
      </defs>
      <!-- 50% Neutral Grid Line -->
      <line x1="${padding}" y1="${height - padding - (0.5 * innerH)}" x2="${width - padding}" y2="${height - padding - (0.5 * innerH)}" stroke="rgba(255,255,255,0.12)" stroke-dasharray="4" stroke-width="1"/>
      <text x="${width - padding - 4}" y="${height - padding - (0.5 * innerH) - 4}" fill="rgba(255,255,255,0.3)" font-size="9" text-anchor="end">50% Line</text>

      <!-- Fill Area -->
      <path d="${areaD}" fill="url(#chartGradient)"/>

      <!-- Glowing Line -->
      <path d="${pathD}" fill="none" stroke="${batColor}" stroke-width="3" filter="drop-shadow(0 0 6px ${batColor})"/>

      <!-- Data Dots -->
      ${points.filter((_, i) => i % 3 === 0 || i === points.length - 1).map(pt => `
        <circle cx="${pt.x}" cy="${pt.y}" r="4" fill="#fff" stroke="${batColor}" stroke-width="2"/>
      `).join('')}
    `;
  }

  // Run initialization
  init();
});

// Helper for Stepper buttons
window.adjustValue = function(inputId, step) {
  const input = document.getElementById(inputId);
  if (!input) return;
  const current = parseInt(input.value) || 0;
  const min = parseInt(input.min) || 0;
  const max = parseInt(input.max) || 350;
  const next = Math.max(min, Math.min(max, current + step));
  input.value = next;
  input.dispatchEvent(new Event('input'));
};

// Helper for Overs Quick Buttons
window.setOvers = function(oversVal) {
  const slider = document.getElementById('oversRange');
  if (!slider) return;
  slider.value = oversVal;
  slider.dispatchEvent(new Event('input'));
};
