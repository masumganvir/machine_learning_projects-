"""
IPL Win Probability Predictor - Software Module & CLI Interface
Can be imported directly into any software:
    from predict_cli import IPLPredictor
    predictor = IPLPredictor()
    result = predictor.predict('Mumbai Indians', 'Chennai Super Kings', 'Mumbai', 180, 135, 15.0, 3)
"""

import os
import sys
import pickle
import pandas as pd

class IPLPredictor:
    TEAMS = [
        'Chennai Super Kings',
        'Delhi Capitals',
        'Kings XI Punjab',
        'Kolkata Knight Riders',
        'Mumbai Indians',
        'Rajasthan Royals',
        'Royal Challengers Bangalore',
        'Sunrisers Hyderabad'
    ]

    CITIES = [
        'Abu Dhabi', 'Ahmedabad', 'Bangalore', 'Bengaluru', 'Bloemfontein',
        'Cape Town', 'Centurion', 'Chandigarh', 'Chennai', 'Cuttack',
        'Delhi', 'Dharamsala', 'Durban', 'East London', 'Hyderabad',
        'Indore', 'Jaipur', 'Johannesburg', 'Kimberley', 'Kolkata',
        'Mohali', 'Mumbai', 'Nagpur', 'Port Elizabeth', 'Pune',
        'Raipur', 'Ranchi', 'Sharjah', 'Visakhapatnam'
    ]

    def __init__(self, model_path='pipe.pkl'):
        self.model_path = model_path
        self.model = self._load_model()

    def _load_model(self):
        if not os.path.exists(self.model_path):
            raise FileNotFoundError(f"Model file '{self.model_path}' not found. Run train_model.py first.")
        with open(self.model_path, 'rb') as f:
            return pickle.load(f)

    def predict(self, batting_team, bowling_team, city, target, score, overs, wickets_out):
        """
        Predict win and loss probability for an ongoing chase.
        
        Parameters:
            batting_team (str): Name of chasing team
            bowling_team (str): Name of defending team
            city (str): Host venue city
            target (int): Target runs to chase
            score (int): Current score
            overs (float): Overs completed (e.g. 15.2 means 15 overs and 2 balls, or decimal 15.33)
            wickets_out (int): Number of wickets fallen (0-10)
        """
        # Convert fractional cricket balls e.g. 15.2 overs -> 15*6 + 2 = 92 balls
        whole_overs = int(overs)
        balls_in_over = int(round((overs - whole_overs) * 10))
        if balls_in_over >= 6:
            balls_bowled = int(round(overs * 6))
        else:
            balls_bowled = whole_overs * 6 + balls_in_over

        if balls_bowled <= 0:
            balls_bowled = 1  # prevent division by zero

        balls_left = 120 - balls_bowled
        if balls_left <= 0:
            balls_left = 1

        runs_left = target - score
        wickets_remaining = 10 - wickets_out

        crr = (score * 6) / balls_bowled
        rrr = (runs_left * 6) / balls_left

        input_df = pd.DataFrame([{
            'batting_team': batting_team,
            'bowling_team': bowling_team,
            'city': city,
            'runs_left': runs_left,
            'balls_left': balls_left,
            'wickets': wickets_remaining,
            'total_runs_x': target,
            'crr': crr,
            'rrr': rrr
        }])

        proba = self.model.predict_proba(input_df)[0]
        loss_prob = float(proba[0])
        win_prob = float(proba[1])

        return {
            'batting_team': batting_team,
            'bowling_team': bowling_team,
            'city': city,
            'target': target,
            'score': score,
            'overs': overs,
            'wickets_out': wickets_out,
            'runs_left': runs_left,
            'balls_left': balls_left,
            'wickets_remaining': wickets_remaining,
            'crr': round(crr, 2),
            'rrr': round(rrr, 2),
            'win_probability': round(win_prob * 100, 1),
            'loss_probability': round(loss_prob * 100, 1),
            'favored_team': batting_team if win_prob >= 0.5 else bowling_team
        }

def run_cli():
    print("=" * 60)
    print("🏏 IPL WIN PROBABILITY PREDICTOR - SOFTWARE CONSOLE 🏏")
    print("=" * 60)
    predictor = IPLPredictor()
    
    print("\nSupported Teams:")
    for idx, t in enumerate(predictor.TEAMS, 1):
        print(f"  {idx}. {t}")
        
    try:
        b_idx = int(input("\nSelect Batting Team (1-8): ")) - 1
        batting_team = predictor.TEAMS[b_idx]
        
        bw_idx = int(input("Select Bowling Team (1-8): ")) - 1
        bowling_team = predictor.TEAMS[bw_idx]
        
        print("\nSelect City (e.g. Mumbai, Chennai, Kolkata, Bangalore):")
        city = input("Host City: ").strip()
        if city not in predictor.CITIES:
            city = 'Mumbai'
            print(f"Defaulting to '{city}'")
            
        target = int(input("Target Score: "))
        score = int(input("Current Score: "))
        overs = float(input("Overs Completed (e.g. 15.2): "))
        wickets = int(input("Wickets Fallen (0-10): "))
        
        res = predictor.predict(batting_team, bowling_team, city, target, score, overs, wickets)
        
        print("\n" + "=" * 60)
        print("MATCH PREDICTION RESULTS")
        print("=" * 60)
        print(f"Match State: {batting_team} needs {res['runs_left']} runs from {res['balls_left']} balls with {res['wickets_remaining']} wickets in hand.")
        print(f"CRR: {res['crr']} | RRR: {res['rrr']}")
        print(f"\n🏆 {batting_team} Win Probability: {res['win_probability']}%")
        print(f"🛡️ {bowling_team} Win Probability: {res['loss_probability']}%")
        print(f"Predicted Favorite: {res['favored_team']}")
        print("=" * 60)
    except Exception as e:
        print(f"Error: {e}")

if __name__ == '__main__':
    if len(sys.argv) > 1 and sys.argv[1] == '--test':
        pred = IPLPredictor()
        test_res = pred.predict('Mumbai Indians', 'Chennai Super Kings', 'Mumbai', 180, 135, 15.0, 3)
        print("Test Result:", test_res)
        assert 'win_probability' in test_res
        print("Software test passed successfully!")
    else:
        run_cli()
