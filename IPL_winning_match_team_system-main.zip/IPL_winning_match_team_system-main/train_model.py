import os
import pickle
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline
from sklearn.metrics import accuracy_score, classification_report

def train_and_export_model(matches_path=None, deliveries_path=None, output_pickle=None):
    base_dir = os.path.dirname(os.path.abspath(__file__))
    if matches_path is None:
        matches_path = os.path.join(base_dir, 'matches.csv')
    if deliveries_path is None:
        deliveries_path = os.path.join(base_dir, 'deliveries.csv')
    if output_pickle is None:
        output_pickle = os.path.join(base_dir, 'pipe.pkl')

    print(f"Loading data from {matches_path} and {deliveries_path}...")
    if not os.path.exists(matches_path) or not os.path.exists(deliveries_path):
        raise FileNotFoundError(f"Missing {matches_path} or {deliveries_path} in current directory.")

    match = pd.read_csv(matches_path)
    delivery = pd.read_csv(deliveries_path)

    # 1. Total score in 1st innings
    total_score_df = delivery.groupby(['match_id', 'inning'])['total_runs'].sum().reset_index()
    total_score_df = total_score_df[total_score_df['inning'] == 1]

    # 2. Merge with match dataset
    match_df = match.merge(total_score_df[['match_id', 'total_runs']], left_on='id', right_on='match_id')

    # Standardize team names
    teams = [
        'Sunrisers Hyderabad',
        'Mumbai Indians',
        'Royal Challengers Bangalore',
        'Kolkata Knight Riders',
        'Kings XI Punjab',
        'Chennai Super Kings',
        'Rajasthan Royals',
        'Delhi Capitals'
    ]

    match_df['team1'] = match_df['team1'].str.replace('Delhi Daredevils', 'Delhi Capitals')
    match_df['team2'] = match_df['team2'].str.replace('Delhi Daredevils', 'Delhi Capitals')
    match_df['team1'] = match_df['team1'].str.replace('Deccan Chargers', 'Sunrisers Hyderabad')
    match_df['team2'] = match_df['team2'].str.replace('Deccan Chargers', 'Sunrisers Hyderabad')

    match_df = match_df[match_df['team1'].isin(teams)]
    match_df = match_df[match_df['team2'].isin(teams)]
    match_df = match_df[match_df['dl_applied'] == 0]
    match_df = match_df[['match_id', 'city', 'winner', 'total_runs']]

    # 3. Merge with 2nd innings deliveries
    delivery_df = match_df.merge(delivery, on='match_id')
    delivery_df = delivery_df[delivery_df['inning'] == 2]

    # Calculate match state features
    delivery_df['current_score'] = delivery_df.groupby('match_id')['total_runs_y'].cumsum()
    delivery_df['runs_left'] = delivery_df['total_runs_x'] - delivery_df['current_score']
    delivery_df['balls_left'] = 126 - (delivery_df['over'] * 6 + delivery_df['ball'])

    delivery_df['player_dismissed'] = delivery_df['player_dismissed'].fillna('0')
    delivery_df['player_dismissed'] = delivery_df['player_dismissed'].apply(lambda x: 0 if x == '0' else 1).astype('int')
    wickets = delivery_df.groupby('match_id')['player_dismissed'].cumsum().values
    delivery_df['wickets'] = 10 - wickets

    # Run Rates
    delivery_df['crr'] = (delivery_df['current_score'] * 6) / (120 - delivery_df['balls_left'])
    delivery_df['rrr'] = (delivery_df['runs_left'] * 6) / delivery_df['balls_left']

    # Target variable
    delivery_df['result'] = delivery_df.apply(lambda row: 1 if row['batting_team'] == row['winner'] else 0, axis=1)

    # Filter features
    final_df = delivery_df[['batting_team', 'bowling_team', 'city', 'runs_left', 'balls_left', 'wickets', 'total_runs_x', 'crr', 'rrr', 'result']].copy()
    final_df = final_df.sample(frac=1.0, random_state=42)
    final_df.dropna(inplace=True)
    final_df = final_df[final_df['balls_left'] > 0]

    X = final_df.iloc[:, :-1]
    y = final_df.iloc[:, -1]

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=1)

    print(f"Dataset prepared: {X_train.shape[0]} training samples, {X_test.shape[0]} test samples.")

    # 4. Pipeline with OneHotEncoder and LogisticRegression
    trf = ColumnTransformer([
        ('trf', OneHotEncoder(sparse_output=False, drop='first'), ['batting_team', 'bowling_team', 'city'])
    ], remainder='passthrough')

    pipe = Pipeline(steps=[
        ('step1', trf),
        ('step2', LogisticRegression(solver='liblinear', C=1.0, random_state=42))
    ])

    print("Training Logistic Regression Pipeline...")
    pipe.fit(X_train, y_train)

    y_pred = pipe.predict(X_test)
    acc = accuracy_score(y_test, y_pred)
    print(f"Model Training Complete! Accuracy: {acc * 100:.2f}%")
    print(classification_report(y_test, y_pred))

    # 5. Export to pickle
    with open(output_pickle, 'wb') as f:
        pickle.dump(pipe, f)
    print(f"Serialized model successfully saved to '{output_pickle}' ({os.path.getsize(output_pickle)} bytes).")
    return pipe

if __name__ == '__main__':
    train_and_export_model()
