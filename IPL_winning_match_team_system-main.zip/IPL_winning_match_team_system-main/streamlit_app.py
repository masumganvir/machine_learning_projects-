import os
import pickle
import pandas as pd
import streamlit as st

# Configure page
st.set_page_config(
    page_title="IPL Win Probability Predictor",
    page_icon="🏏",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom Styling Injection
st.markdown("""
<style>
    .main {
        background-color: #070b19;
    }
    .metric-card {
        background: rgba(14, 22, 48, 0.7);
        border: 1px solid rgba(255, 255, 255, 0.1);
        border-radius: 12px;
        padding: 16px;
        text-align: center;
        margin-bottom: 12px;
    }
    .prob-val {
        font-size: 32px;
        font-weight: 800;
        color: #00e5ff;
    }
</style>
""", unsafe_allow_html=True)

TEAMS = [
    'Chennai Super Kings',
    'Delhi Capitals',
    'Kings XI Punjab',
    'Kolkata Knight Riders',
    'Mumbai Indians',
    'Rajasthan Royals',
    'Royal Challengers Bangalore',
    'Sunrisers Hyderabad'
]

CITIES = [
    'Abu Dhabi', 'Ahmedabad', 'Bangalore', 'Bengaluru', 'Bloemfontein',
    'Cape Town', 'Centurion', 'Chandigarh', 'Chennai', 'Cuttack',
    'Delhi', 'Dharamsala', 'Durban', 'East London', 'Hyderabad',
    'Indore', 'Jaipur', 'Johannesburg', 'Kimberley', 'Kolkata',
    'Mohali', 'Mumbai', 'Nagpur', 'Port Elizabeth', 'Pune',
    'Raipur', 'Ranchi', 'Sharjah', 'Visakhapatnam'
]

MODEL_PATH = os.path.join(os.path.dirname(__file__), 'pipe.pkl')

@st.cache_resource
def load_pipe():
    if not os.path.exists(MODEL_PATH):
        st.error("Model pipe.pkl not found! Please run train_model.py first.")
        return None
    with open(MODEL_PATH, 'rb') as f:
        return pickle.load(f)

pipe = load_pipe()

st.title("🏏 IPL Win Probability Predictor")
st.caption("AI-Powered Live Match Chase Analyzer | Logistic Regression Engine")

# Sidebar Match Configuration
with st.sidebar:
    st.header("Match Setup")
    batting_team = st.selectbox('Chasing Team (Batting)', sorted(TEAMS), index=4)
    available_bowling = [t for t in sorted(TEAMS) if t != batting_team]
    bowling_team = st.selectbox('Defending Team (Bowling)', available_bowling, index=0)
    selected_city = st.selectbox('Host Venue / City', sorted(CITIES), index=sorted(CITIES).index('Mumbai'))
    st.divider()
    st.markdown("### Model Details")
    st.info("Trained on 57,000+ IPL chase deliveries. Scikit-Learn Pipeline with OneHotEncoding & Logistic Regression.")

col1, col2, col3, col4 = st.columns(4)
with col1:
    target = st.number_input('Target Score', min_value=1, max_value=350, value=180, step=1)
with col2:
    score = st.number_input('Current Score', min_value=0, max_value=350, value=135, step=1)
with col3:
    overs = st.number_input('Overs Completed', min_value=0.1, max_value=19.5, value=15.0, step=0.1)
with col4:
    wickets = st.number_input('Wickets Fallen', min_value=0, max_value=9, value=3, step=1)

# Live calculation metrics
whole_overs = int(overs)
balls_in_over = int(round((overs - whole_overs) * 10))
balls_bowled = whole_overs * 6 + (balls_in_over if balls_in_over < 6 else 6)
balls_bowled = max(1, min(120, balls_bowled))
balls_left = max(1, 120 - balls_bowled)
runs_left = max(0, target - score)
wickets_left = 10 - wickets
crr = (score * 6) / balls_bowled
rrr = (runs_left * 6) / balls_left

m1, m2, m3, m4 = st.columns(4)
m1.metric("Runs Needed", runs_left)
m2.metric("Balls Remaining", balls_left)
m3.metric("Current Run Rate (CRR)", f"{crr:.2f}")
m4.metric("Required Run Rate (RRR)", f"{rrr:.2f}")

st.write("")
if st.button('⚡ Predict Probability', use_container_width=True):
    if pipe is not None:
        input_df = pd.DataFrame([{
            'batting_team': batting_team,
            'bowling_team': bowling_team,
            'city': selected_city,
            'runs_left': runs_left,
            'balls_left': balls_left,
            'wickets': wickets_left,
            'total_runs_x': target,
            'crr': crr,
            'rrr': rrr
        }])

        result = pipe.predict_proba(input_df)
        loss = result[0][0]
        win = result[0][1]

        rcol1, rcol2 = st.columns(2)
        with rcol1:
            st.success(f"**{batting_team} (Chasing)**")
            st.metric("Win Probability", f"{round(win * 100, 1)}%")
            st.progress(float(win))
        with rcol2:
            st.warning(f"**{bowling_team} (Defending)**")
            st.metric("Win Probability", f"{round(loss * 100, 1)}%")
            st.progress(float(loss))
