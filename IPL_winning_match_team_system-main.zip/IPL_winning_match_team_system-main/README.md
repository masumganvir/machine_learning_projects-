# 🏏 IPL Win Probability Predictor

An end-to-end Machine Learning full-stack web application that predicts the win probability of Indian Premier League (IPL) matches in real-time during the second-innings chase.

Built with a **Scikit-Learn Logistic Regression Pipeline**, a **Flask REST API**, and a modern **animated cricket stadium dashboard UI**.

---

## 🌟 Features

- **Live Chase Match Center**: Computes **Runs Needed**, **Balls Remaining**, **Current Run Rate (CRR)**, and **Required Run Rate (RRR)** dynamically as inputs change.
- **Dynamic Stadium Theming**: Matchup header and ambient lighting adapt in real time to the selected batting and bowling teams (e.g. MI Blue vs CSK Gold).
- **Smooth Radial Gauges**: 60fps SVG circular meters with animated numeric interpolation.
- **Duel Tug-of-War Bar**: Real-time balance-of-power indicator showing match momentum.
- **Projected Progression Simulator**: Over-by-over win probability projection trajectory curve.
- **Instant Match Presets**: Pre-configured historic cliffhangers (2019 Final thriller, High-scoring chase, Low-scoring defense).
- **Dual Application Framework**:
  - Full-stack web app (`app.py`) for production web & Render deployment.
  - Interactive Streamlit app (`streamlit_app.py`) for exploratory work.
- **Software / CLI Module**: Standalone `IPLPredictor` class (`predict_cli.py`) for external software integration.

---

## 🚀 Quick Start (Local Run)

### 1. Install Dependencies
```bash
pip install -r requirements.txt
```

### 2. (Optional) Retrain Model
The repository already includes the pre-trained `pipe.pkl` (~80.45% accuracy). To retrain:
```bash
python train_model.py
```

### 3. Launch Web Application
```bash
python app.py
```
Open your browser at `http://127.0.0.1:5000` to interact with the dashboard.

### 4. Or Run Streamlit App
```bash
streamlit run streamlit_app.py
```

---

## 💻 Using in External Software / CLI

Import the predictor directly into any Python application:

```python
from predict_cli import IPLPredictor

predictor = IPLPredictor()
result = predictor.predict(
    batting_team='Mumbai Indians',
    bowling_team='Chennai Super Kings',
    city='Mumbai',
    target=180,
    score=135,
    overs=15.0,
    wickets_out=3
)

print(f"Win Probability: {result['win_probability']}%")
print(f"Required Run Rate: {result['rrr']}")
```

Or run via interactive terminal console:
```bash
python predict_cli.py
```

---

## 🌐 Deploying on Render (Step-by-Step)

This repository is pre-configured for turnkey deployment on [Render](https://render.com).

### Method 1: Using Render Blueprint (`render.yaml`)
1. Push this repository to your GitHub account.
2. Log in to [Render Dashboard](https://dashboard.render.com).
3. Click **New +** > **Blueprint**.
4. Connect your repository. Render will automatically detect `render.yaml` and configure:
   - **Environment**: Python
   - **Build Command**: `pip install -r requirements.txt`
   - **Start Command**: `gunicorn app:app --bind 0.0.0.0:$PORT`
5. Click **Apply**. Your app will be live within 2-3 minutes!

### Method 2: Manual Web Service on Render
1. In Render, select **New +** > **Web Service**.
2. Connect your GitHub repository.
3. Choose **Python** as runtime.
4. Set:
   - **Build Command**: `pip install -r requirements.txt`
   - **Start Command**: `gunicorn app:app --bind 0.0.0.0:$PORT`
5. Select the **Free** instance type and click **Create Web Service**.

---

## 📡 REST API Documentation

### 1. Health Check
`GET /api/health`
```json
{
  "status": "healthy",
  "service": "ipl-win-probability-predictor",
  "model_loaded": true
}
```

### 2. Predict Win Probability
`POST /api/predict`
```json
{
  "batting_team": "Mumbai Indians",
  "bowling_team": "Chennai Super Kings",
  "city": "Mumbai",
  "target": 180,
  "score": 135,
  "overs": 15.0,
  "wickets": 3
}
```

**Response:**
```json
{
  "status": "success",
  "batting_team": "Mumbai Indians",
  "bowling_team": "Chennai Super Kings",
  "win_probability": 86.4,
  "loss_probability": 13.6,
  "runs_left": 45,
  "balls_left": 30,
  "wickets_remaining": 7,
  "crr": 9.0,
  "rrr": 9.0,
  "momentum": "Strong Advantage: Mumbai Indians",
  "summary": "Mumbai Indians needs 45 runs from 30 balls with 7 wickets in hand."
}
```

### 3. Match Progression Simulation
`POST /api/progression`

Simulates over-by-over probability trajectory from Over 1 to Over 20.
