# Mental Health Signal & AI Wellness Companion

An intelligent student wellness analytics and mental health prediction system. This application analyzes various lifestyle and academic metrics (like sleep, screen time, physical activity, and stress) to predict a student's mental health score out of 10. Based on the score, it provides highly personalized, clinical-grade wellness insights using the Gemini Generative AI.

## 🚀 Features

- **Mental Health Prediction**: Predicts a wellness score based on a Random Forest Regression model trained on student lifestyle datasets.
- **AI-Powered Insights**: Integrates with the **Gemini API** to provide empathetic, contextual feedback, highlighting key observations and generating a tailored action plan.
- **Smart Wellness Fallback**: If the Gemini API is unavailable or unconfigured, the app falls back to a built-in clinical rule-based engine to provide actionable advice.
- **Responsive UI**: A modern, aesthetically pleasing, and dynamic user interface using vanilla HTML, CSS, and JavaScript.
- **FastAPI Backend**: A lightweight, high-performance API that serves the frontend and handles prediction requests.

## 🧠 The Machine Learning Model

The prediction engine is powered by a **Random Forest Regressor** (`Mental_Health_Model.pkl`). The model was trained to predict a mental health score (0-10) using the following features:
- **Demographics**: Age, Gender, Country
- **Academics**: Academic Level, Study Hours
- **Digital Habits**: Most Used Platform, Purpose of Use, Daily Screen Time, Daily Unlocks
- **Lifestyle**: Sleep Hours, Physical Activity, Perceived Stress Level

A higher score (e.g., > 7.5) indicates high wellness and resilience, while a lower score highlights potential strain, fatigue, or burnout.

## 🛠️ Usage

### Prerequisites
- Python 3.9+
- A Gemini API Key (optional but recommended for dynamic AI responses)

### Installation

1. **Clone the repository**:
   ```bash
   git clone https://github.com/masumganvir/Mental_health_prediction_system.git
   cd Mental_health_prediction_system
   ```

2. **Install dependencies**:
   ```bash
   pip install -r requirements.txt
   ```

3. **Configure the Environment**:
   Create a `.env` file in the root directory and add your Gemini API key to enable AI insights:
   ```env
   GEMINI_API_KEY=your_gemini_api_key_here
   ```
   *(If you don't add an API key, the app will automatically use its built-in rule-based fallback engine).*

### Running the Web App

Start the FastAPI application using Uvicorn:
```bash
python -m uvicorn main:app --port 2200 --reload
```

Then, open your web browser and navigate to:
(https://mental-health-prediction-system-x7ev.onrender.com)

## 🤝 Author
Created by **Masum Ganvir**.
