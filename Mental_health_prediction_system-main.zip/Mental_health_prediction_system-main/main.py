import os
import json
import logging
import joblib
import pandas as pd
import httpx
from dotenv import load_dotenv
from fastapi import FastAPI, Request, Response
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field
from typing import Literal, List, Optional
from fastapi.middleware.cors import CORSMiddleware

# Load environment variables (.env file)
load_dotenv()

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("mental_health_api")

# Load trained model
model = joblib.load('Mental_Health_Model.pkl')
top_countries = ['Other', 'India', 'USA', 'Canada', 'Australia', 'UK', 'Germany', 'Mexico', 'Turkey', 'France']

app = FastAPI(title="Mental Health Signal & AI Counselor")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


# Input Schema
class StudentData(BaseModel):
    age                     : int = Field(..., ge=10, le=100)
    gender                  : Literal['Male', 'Female']
    country                 : str
    academic_level          : Literal['Undergraduate', 'Graduate', 'High School']
    most_used_platform      : Literal['Facebook', 'LinkedIn', 'Instagram', 'Snapchat','Twitter','YouTube', 'TikTok', 'LINE', 'KakaoTalk', 'VKontakte', 'WhatsApp','WeChat']
    purpose_of_use          : Literal['Networking', 'Education', 'Entertainment', 'News']
    avg_daily_usage_hours   : float = Field(..., ge=0, le=24)
    daily_unlocks           : int   = Field(..., ge=0)
    study_hours             : float = Field(..., ge=0, le=24)
    physical_activity_hours : float = Field(..., ge=0, le=24)
    sleep_hours_per_night   : float = Field(..., ge=0, le=24)
    stress_level            : Literal['Medium', 'Low', 'Very High', 'High']


# AI Output Schemas
class ActionItem(BaseModel):
    category: str
    action: str
    impact: str
    tip: str


class AIRecommendation(BaseModel):
    source: str  # "gemini" or "wellness_engine"
    appreciation: str
    summary: str
    key_observations: List[str]
    action_plan: List[ActionItem]
    encouragement: str


class PredictionResponse(BaseModel):
    predicted_mental_health_score: float
    score_category: str
    score_summary: str
    ai_insights: AIRecommendation


def build_rule_based_wellness_insights(data: StudentData, score: float) -> AIRecommendation:
    """Intelligent clinical/lifestyle fallback when Gemini key is not configured or offline."""
    observations = []
    actions = []

    # Score category & appreciative narrative
    if score >= 7.5:
        category = "Thriving & Resilient"
        appreciation = (
            f"Remarkable work! Balancing {data.academic_level.lower()} academics with personal well-being is no small feat. "
            f"Your current daily rhythm shows admirable resilience and healthy grounding."
        )
        summary = "Your daily habits strongly buffer you against chronic academic stress."
    elif score >= 5.5:
        category = "Balanced with Growth Areas"
        appreciation = (
            f"You are doing a commendable job managing student life! You have established good foundational habits, "
            f"and with a few minor tune-ups to your screen habits and rest, you can feel even more energized."
        )
        summary = "A stable baseline with targeted opportunities to reclaim mental focus and reduce fatigue."
    elif score >= 4.0:
        category = "Moderate Strain Detected"
        appreciation = (
            f"We want to sincerely acknowledge how hard you're working. Being a {data.academic_level.lower()} student carries "
            f"real mental load, and feeling stretched thin is completely valid. You deserve intentional time to recharge."
        )
        summary = "Signs of digital overload and restorative deficit are impacting your natural equilibrium."
    else:
        category = "High Fatigue & Cognitive Overload"
        appreciation = (
            f"Please take a gentle breath — you are carrying a lot on your shoulders right now. Acknowledging where you are "
            f"is the very first courageous step. You don't have to fix everything at once, but small restorative shifts will help you breathe easier."
        )
        summary = "Your system is signaling burnout signals from high screen exposure, stress, or low recovery."

    # Analyze Sleep
    if data.sleep_hours_per_night < 6.0:
        observations.append(f"Sleep Deficit: At {data.sleep_hours_per_night}h/night, your brain lacks full REM and deep restorative cycles.")
        actions.append(ActionItem(
            category="Rest & Recovery",
            action="Extend nightly sleep toward 7–8 hours",
            impact="Reduces emotional reactivity by 35% and boosts memory consolidation for your studies.",
            tip="Establish a 30-minute tech-free wind-down window before bed with low lighting."
        ))
    elif data.sleep_hours_per_night >= 7.5:
        observations.append(f"Restorative Sleep: Getting {data.sleep_hours_per_night}h of sleep is a massive positive protective factor.")

    # Analyze Screen Time & Unlocks
    if data.avg_daily_usage_hours > 5.0 or data.daily_unlocks > 70:
        observations.append(
            f"Digital Hyper-connectivity: {data.avg_daily_usage_hours}h daily on {data.most_used_platform} and {data.daily_unlocks} unlocks "
            f"create persistent micro-distractions."
        )
        actions.append(ActionItem(
            category="Digital Detox",
            action=f"Curate a 'Downtime Window' for {data.most_used_platform}",
            impact="Restores dopamine baseline, decreases doomscrolling anxiety, and frees up mental clarity.",
            tip=f"Set a daily limit of 2h on {data.most_used_platform} and keep the phone in another room while studying."
        ))
    elif data.avg_daily_usage_hours <= 3.0:
        observations.append(f"Conscious Screen Usage: Averaging only {data.avg_daily_usage_hours}h/day shows healthy digital restraint.")

    # Analyze Physical Activity
    if data.physical_activity_hours < 1.0:
        observations.append("Sedentary Strain: Under 1 hour of movement limits physical stress dissipation.")
        actions.append(ActionItem(
            category="Body & Energy",
            action="Incorporate 20–30 minutes of low-intensity movement",
            impact="Triggers endorphin release and lowers circulating cortisol levels caused by academic stress.",
            tip="A morning brisk walk without headphones or 15 minutes of light stretching between study sessions."
        ))
    else:
        observations.append(f"Active Lifestyle: {data.physical_activity_hours}h of physical movement is keeping your brain oxygenated and resilient.")

    # Analyze Stress & Study
    if data.stress_level in ['High', 'Very High']:
        observations.append(f"Heightened Stress: Self-reported {data.stress_level.lower()} stress indicates high nervous system activation.")
        actions.append(ActionItem(
            category="Mindfulness & Focus",
            action="Adopt Box Breathing or the 4-7-8 technique",
            impact="Downregulates the sympathetic nervous system within 90 seconds.",
            tip="Practice 3 minutes of 4-7-8 breathing right before study sessions or when feeling overwhelmed."
        ))

    # Fallback action item if list is short
    if len(actions) < 3:
        actions.append(ActionItem(
            category="Study Rhythm",
            action="Adopt the 50/10 Pomodoro cadence",
            impact="Prevents cognitive fatigue and maintains sustained absorption during study hours.",
            tip=f"For your {data.study_hours} study hours, take a deliberate 10-minute break away from screens every 50 minutes."
        ))

    encouragement = (
        "Remember: Progress is built through small, consistent rituals — not overnight perfection. "
        "Take one adjustment that feels effortless today, and build momentum gently."
    )

    return AIRecommendation(
        source="wellness_engine",
        appreciation=appreciation,
        summary=summary,
        key_observations=observations,
        action_plan=actions[:4],
        encouragement=encouragement
    )


async def get_gemini_ai_insights(data: StudentData, score: float) -> AIRecommendation:
    """Calls Gemini API using API key from .env, gracefully falling back if unavailable."""
    api_key = os.getenv("GEMINI_API_KEY", "").strip()

    if not api_key:
        logger.info("No GEMINI_API_KEY found in environment. Using smart wellness engine.")
        return build_rule_based_wellness_insights(data, score)

    prompt = f"""
You are an empathetic, clinical wellness advisor specialized in student mental health and lifestyle habits.
Analyze the following student assessment data:

Student Profile:
- Age: {data.age}
- Gender: {data.gender}
- Academic Level: {data.academic_level}
- Country: {data.country}
- Most Used Platform: {data.most_used_platform} (Purpose: {data.purpose_of_use})
- Daily Screen Time: {data.avg_daily_usage_hours} hours
- Daily Phone Unlocks: {data.daily_unlocks} times
- Nightly Sleep: {data.sleep_hours_per_night} hours
- Daily Study Hours: {data.study_hours} hours
- Physical Activity: {data.physical_activity_hours} hours
- Perceived Stress Level: {data.stress_level}
- Predicted Mental Health Score: {score}/10 (Higher score = better mental wellness and balance; Lower = higher strain/burnout)

Instructions:
1. "appreciation": Warmly appreciate and validate the student's effort, recognizing their academic commitments and acknowledging their positive strengths.
2. "summary": A concise, thoughtful 1-2 sentence overview of how their daily rhythm aligns with their score.
3. "key_observations": 3 to 4 bullet observations detailing specific connections between their habits (screen time, unlocks, sleep deficit, physical activity) and their score.
4. "action_plan": Exactly 3 to 4 concrete, realistic, high-impact lifestyle modifications they should make to improve their score and wellness (e.g. reducing screen time on {data.most_used_platform}, sleep schedule, study breaks, physical movement). Each with:
   - "category": Short label like "Digital Detox", "Rest & Sleep", "Physical Vitality", "Stress Relief"
   - "action": Specific action
   - "impact": Why it helps biologically or psychologically
   - "tip": An easy, frictionless tip to start today
5. "encouragement": A compassionate closing thought reminding them that small steps lead to profound wellness shifts.

Return ONLY a valid JSON object matching this schema:
{{
  "appreciation": "...",
  "summary": "...",
  "key_observations": ["...", "..."],
  "action_plan": [
    {{
      "category": "...",
      "action": "...",
      "impact": "...",
      "tip": "..."
    }}
  ],
  "encouragement": "..."
}}
"""

    # Try Gemini 2.0 Flash or 1.5 Flash models
    for model_name in ["gemini-2.0-flash", "gemini-1.5-flash"]:
        try:
            url = f"https://generativelanguage.googleapis.com/v1beta/models/{model_name}:generateContent?key={api_key}"
            payload = {
                "contents": [{"parts": [{"text": prompt}]}],
                "generationConfig": {
                    "temperature": 0.7,
                    "responseMimeType": "application/json"
                }
            }
            async with httpx.AsyncClient(timeout=12.0) as client:
                res = await client.post(url, json=payload)
                if res.status_code == 200:
                    resp_json = res.json()
                    raw_text = resp_json["candidates"][0]["content"]["parts"][0]["text"]
                    parsed = json.loads(raw_text)
                    return AIRecommendation(
                        source=f"gemini ({model_name})",
                        appreciation=parsed.get("appreciation", ""),
                        summary=parsed.get("summary", ""),
                        key_observations=parsed.get("key_observations", []),
                        action_plan=[ActionItem(**item) for item in parsed.get("action_plan", [])],
                        encouragement=parsed.get("encouragement", "")
                    )
                else:
                    logger.warning(f"Gemini API returned status {res.status_code}: {res.text}")
        except Exception as e:
            logger.warning(f"Failed to call Gemini ({model_name}): {e}")

    logger.info("Falling back to built-in wellness insights engine.")
    return build_rule_based_wellness_insights(data, score)


# -------------------------------------------------------------
# Routes
# -------------------------------------------------------------

@app.get('/')
def home(request: Request):
    accept = request.headers.get("accept", "")
    if "application/json" in accept and "text/html" not in accept:
        return {'Hallo this is Masum Ganvir and I hope you are doing great.'}
    return FileResponse('index.html')


@app.get('/style.css')
def serve_css():
    return FileResponse('style.css', media_type='text/css')


@app.get('/script.js')
def serve_js():
    return FileResponse('script.js', media_type='application/javascript')


@app.get('/favicon.ico', include_in_schema=False)
def favicon():
    return Response(status_code=204)


@app.get('/greet')
def greet():
    return {'Hallo this is Masum Ganvir and I hope you are doing great.'}


@app.get('/api/status')
def api_status():
    api_key = os.getenv("GEMINI_API_KEY", "").strip()
    return {
        "status": "online",
        "gemini_configured": bool(api_key),
        "model": "RandomForestRegressor (Mental Health)",
        "author": "Masum Ganvir"
    }


@app.post('/predict', response_model=PredictionResponse)
async def predict(data: StudentData):
    country_group = data.country if data.country in top_countries else "Other"

    input_row = pd.DataFrame([{
        'Age'                       : data.age,
        'Gender'                    : data.gender,
        'Country'                   : data.country,
        'Academic_Level'            : data.academic_level,
        'Most_Used_Platform'        : data.most_used_platform,
        'Purpose_Of_Use'            : data.purpose_of_use,
        'Avg_Daily_Usage_Hours'     : data.avg_daily_usage_hours,
        'Daily_Unlocks'             : data.daily_unlocks,
        'Study_Hours'               : data.study_hours,
        'Physical_Activity_Hours'   : data.physical_activity_hours,
        'Sleep_Hours_Per_Night'     : data.sleep_hours_per_night,
        'Stress_Level'              : data.stress_level,
        'Grouped_country'           : country_group
    }])

    prediction = float(model.predict(input_row)[0])
    score = max(0.0, min(10.0, round(prediction, 2)))

    # Determine band description
    if score >= 7.5:
        category = "Thriving & High Wellness"
        summary = "Optimal balance across rest, low friction digital habits, and physical activity."
    elif score >= 5.5:
        category = "Balanced Baseline"
        summary = "Moderate wellness with steady emotional rhythm; key habit refinements can unlock peak energy."
    elif score >= 4.0:
        category = "Mild Strain & Fatigue"
        summary = "Digital distraction or sleep deprivation is beginning to exert mental friction."
    else:
        category = "High Stress & Burnout Risk"
        summary = "Intense cognitive strain; priority attention recommended for rest and screen disconnection."

    # Fetch AI Insights (Gemini with smart fallback)
    ai_insights = await get_gemini_ai_insights(data, score)

    return PredictionResponse(
        predicted_mental_health_score=score,
        score_category=category,
        score_summary=summary,
        ai_insights=ai_insights
    )