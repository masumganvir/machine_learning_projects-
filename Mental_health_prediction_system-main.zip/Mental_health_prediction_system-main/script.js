(() => {
  "use strict";

  // API Base URL for Render deployment
  const API_BASE = "https://mental-health-prediction-system-x7ev.onrender.com";

  // Elements
  const form = document.getElementById("predict-form");
  const submitBtn = document.getElementById("submit-btn");
  const resetBtn = document.getElementById("reset-btn");
  const errorRetryBtn = document.getElementById("error-retry-btn");
  const copySummaryBtn = document.getElementById("copy-summary-btn");

  const stateIdle = document.getElementById("state-idle");
  const stateLoading = document.getElementById("state-loading");
  const stateResult = document.getElementById("state-result");
  const stateError = document.getElementById("state-error");

  const scoreNumberEl = document.getElementById("score-number");
  const scoreBandEl = document.getElementById("score-band");
  const scoreSummaryEl = document.getElementById("score-summary");
  const gaugeFill = document.getElementById("gauge-fill");
  const aiSourceBadge = document.getElementById("ai-source-badge");
  const aiAppreciationText = document.getElementById("ai-appreciation-text");
  const observationsList = document.getElementById("observations-list");
  const actionGrid = document.getElementById("action-grid");
  const aiEncouragementText = document.getElementById("ai-encouragement-text");
  const statusText = document.getElementById("status-text");

  const GAUGE_CIRCUMFERENCE = 283; // Arc circumference approx pi * r (90)

  let currentResultData = null;

  // ---------------------------------------------------------
  // Check API Status on Load (Gemini connection detection)
  // ---------------------------------------------------------
  async function checkApiStatus() {
    try {
      const res = await fetch(`${API_BASE}/api/status`);
      if (res.ok) {
        const data = await res.json();
        if (data.gemini_configured) {
          statusText.textContent = "✨ Gemini AI Connected";
        } else {
          statusText.textContent = "🤖 AI Wellness Companion Active";
        }
      }
    } catch (e) {
      console.log("Status check offline or starting...");
    }
  }
  checkApiStatus();

  // ---------------------------------------------------------
  // Render Gauge Ticks
  // ---------------------------------------------------------
  function drawTicks() {
    document.querySelectorAll(".gauge-ticks").forEach((g) => {
      g.innerHTML = "";
      const cx = 120, cy = 135, rOuter = 92, rInner = 82;
      for (let i = 0; i <= 10; i += 1) {
        const angle = Math.PI - (i / 10) * Math.PI; // 180deg -> 0deg
        const x1 = cx + rOuter * Math.cos(angle);
        const y1 = cy - rOuter * Math.sin(angle);
        const isMajor = i % 2 === 0;
        const currentInner = isMajor ? rInner - 3 : rInner;
        const x2 = cx + currentInner * Math.cos(angle);
        const y2 = cy - currentInner * Math.sin(angle);
        const line = document.createElementNS("http://www.w3.org/2000/svg", "line");
        line.setAttribute("x1", x1.toFixed(1));
        line.setAttribute("y1", y1.toFixed(1));
        line.setAttribute("x2", x2.toFixed(1));
        line.setAttribute("y2", y2.toFixed(1));
        if (isMajor) {
          line.style.stroke = "#64748B";
          line.style.strokeWidth = "2";
          line.style.opacity = "0.8";
        }
        g.appendChild(line);
      }
    });
  }
  drawTicks();

  // ---------------------------------------------------------
  // Segmented Control (stress_level)
  // ---------------------------------------------------------
  const segGroup = document.getElementById("stress_level_group");
  const stressHiddenInput = document.getElementById("stress_level");

  segGroup.querySelectorAll(".seg-btn").forEach((btn) => {
    btn.addEventListener("click", () => {
      segGroup.querySelectorAll(".seg-btn").forEach((b) => b.classList.remove("active"));
      btn.classList.add("active");
      stressHiddenInput.value = btn.dataset.value;
      clearFieldError(stressHiddenInput);
    });
  });

  function setStressValue(val) {
    stressHiddenInput.value = val;
    segGroup.querySelectorAll(".seg-btn").forEach((b) => {
      b.classList.toggle("active", b.dataset.value === val);
    });
    clearFieldError(stressHiddenInput);
  }

  // ---------------------------------------------------------
  // Quick Presets
  // ---------------------------------------------------------
  const PRESETS = {
    balanced: {
      age: 21,
      gender: "Male",
      country: "India",
      academic_level: "Undergraduate",
      most_used_platform: "YouTube",
      purpose_of_use: "Education",
      avg_daily_usage_hours: 2.5,
      daily_unlocks: 40,
      sleep_hours_per_night: 7.5,
      study_hours: 5.0,
      physical_activity_hours: 1.5,
      stress_level: "Low"
    },
    screentime: {
      age: 20,
      gender: "Female",
      country: "USA",
      academic_level: "Undergraduate",
      most_used_platform: "Instagram",
      purpose_of_use: "Entertainment",
      avg_daily_usage_hours: 7.0,
      daily_unlocks: 110,
      sleep_hours_per_night: 5.0,
      study_hours: 3.5,
      physical_activity_hours: 0.25,
      stress_level: "High"
    },
    exam: {
      age: 22,
      gender: "Male",
      country: "UK",
      academic_level: "Graduate",
      most_used_platform: "WhatsApp",
      purpose_of_use: "Networking",
      avg_daily_usage_hours: 4.0,
      daily_unlocks: 65,
      sleep_hours_per_night: 4.5,
      study_hours: 8.5,
      physical_activity_hours: 0.5,
      stress_level: "Very High"
    }
  };

  document.querySelectorAll(".preset-btn").forEach((btn) => {
    btn.addEventListener("click", () => {
      const presetKey = btn.dataset.preset;
      const data = PRESETS[presetKey];
      if (!data) return;

      Object.keys(data).forEach((key) => {
        if (key === "stress_level") {
          setStressValue(data[key]);
        } else {
          const input = form.elements[key];
          if (input) {
            input.value = data[key];
            clearFieldError(input);
          }
        }
      });
      // Flash button feedback
      btn.style.transform = "scale(0.95)";
      setTimeout(() => btn.style.transform = "", 150);
    });
  });

  // ---------------------------------------------------------
  // Field Validation & Error Helpers
  // ---------------------------------------------------------
  function setFieldError(input, msg) {
    const name = input.name || input.id;
    const msgEl = form.querySelector(`.error-msg[data-for="${name}"]`);
    if (msgEl) msgEl.textContent = msg;
    input.classList.add("input-invalid");
  }

  function clearFieldError(input) {
    const name = input.name || input.id;
    const msgEl = form.querySelector(`.error-msg[data-for="${name}"]`);
    if (msgEl) msgEl.textContent = "";
    input.classList.remove("input-invalid");
  }

  function clearAllErrors() {
    form.querySelectorAll(".error-msg").forEach((el) => (el.textContent = ""));
    form.querySelectorAll(".input-invalid").forEach((el) => el.classList.remove("input-invalid"));
  }

  // ---------------------------------------------------------
  // State Switching
  // ---------------------------------------------------------
  function showState(state) {
    stateIdle.hidden = state !== "idle";
    stateLoading.hidden = state !== "loading";
    stateResult.hidden = state !== "result";
    stateError.hidden = state !== "error";
  }

  function setSubmitting(isSubmitting) {
    submitBtn.disabled = isSubmitting;
    submitBtn.classList.toggle("submitting", isSubmitting);
  }

  // ---------------------------------------------------------
  // Collect Payload
  // ---------------------------------------------------------
  function collectPayload() {
    const fd = new FormData(form);
    return {
      age: parseInt(fd.get("age"), 10),
      gender: fd.get("gender"),
      country: (fd.get("country") || "").trim(),
      academic_level: fd.get("academic_level"),
      most_used_platform: fd.get("most_used_platform"),
      purpose_of_use: fd.get("purpose_of_use"),
      avg_daily_usage_hours: parseFloat(fd.get("avg_daily_usage_hours")),
      daily_unlocks: parseInt(fd.get("daily_unlocks"), 10),
      study_hours: parseFloat(fd.get("study_hours")),
      physical_activity_hours: parseFloat(fd.get("physical_activity_hours")),
      sleep_hours_per_night: parseFloat(fd.get("sleep_hours_per_night")),
      stress_level: fd.get("stress_level"),
    };
  }

  function validate(p) {
    const errors = [];
    if (isNaN(p.age) || p.age < 10 || p.age > 100) errors.push([form.elements["age"], "Enter an age between 10 and 100."]);
    if (!p.gender) errors.push([form.elements["gender"], "Please select a gender."]);
    if (!p.country) errors.push([form.elements["country"], "Please enter a country."]);
    if (!p.academic_level) errors.push([form.elements["academic_level"], "Please select an academic level."]);
    if (!p.most_used_platform) errors.push([form.elements["most_used_platform"], "Select your primary platform."]);
    if (!p.purpose_of_use) errors.push([form.elements["purpose_of_use"], "Select your primary purpose."]);
    if (isNaN(p.avg_daily_usage_hours) || p.avg_daily_usage_hours < 0 || p.avg_daily_usage_hours > 24)
      errors.push([form.elements["avg_daily_usage_hours"], "Enter daily usage between 0 and 24 hours."]);
    if (isNaN(p.daily_unlocks) || p.daily_unlocks < 0)
      errors.push([form.elements["daily_unlocks"], "Enter 0 or more daily unlocks."]);
    if (isNaN(p.study_hours) || p.study_hours < 0 || p.study_hours > 24)
      errors.push([form.elements["study_hours"], "Enter study hours between 0 and 24."]);
    if (isNaN(p.physical_activity_hours) || p.physical_activity_hours < 0 || p.physical_activity_hours > 24)
      errors.push([form.elements["physical_activity_hours"], "Enter physical activity between 0 and 24."]);
    if (isNaN(p.sleep_hours_per_night) || p.sleep_hours_per_night < 0 || p.sleep_hours_per_night > 24)
      errors.push([form.elements["sleep_hours_per_night"], "Enter sleep hours between 0 and 24."]);
    if (!p.stress_level)
      errors.push([stressHiddenInput, "Select your perceived stress level."]);
    return errors;
  }

  // ---------------------------------------------------------
  // Animate Gauge & Score Number
  // ---------------------------------------------------------
  function animateScore(targetScore) {
    const clamped = Math.max(0, Math.min(10, targetScore));
    // Calculate arc offset: 0 score = 283 offset (empty), 10 score = 0 offset (full)
    const targetOffset = GAUGE_CIRCUMFERENCE * (1 - clamped / 10);
    gaugeFill.style.strokeDashoffset = targetOffset.toFixed(1);

    const startTime = performance.now();
    const duration = 1200;

    function step(now) {
      const progress = Math.min(1, (now - startTime) / duration);
      const easeOut = 1 - Math.pow(1 - progress, 3);
      const current = clamped * easeOut;
      scoreNumberEl.textContent = current.toFixed(1);
      if (progress < 1) {
        requestAnimationFrame(step);
      } else {
        scoreNumberEl.textContent = clamped.toFixed(1);
      }
    }
    requestAnimationFrame(step);
  }

  // ---------------------------------------------------------
  // Render Result & AI Insights
  // ---------------------------------------------------------
  function renderResult(data) {
    currentResultData = data;
    const score = data.predicted_mental_health_score;

    // Score Band styling
    scoreBandEl.textContent = data.score_category || "Assessment Complete";
    scoreBandEl.className = "score-band-pill";
    if (score >= 7.5) {
      scoreBandEl.classList.add("band-thriving");
    } else if (score >= 5.5) {
      scoreBandEl.classList.add("band-balanced");
    } else if (score >= 4.0) {
      scoreBandEl.classList.add("band-strain");
    } else {
      scoreBandEl.classList.add("band-critical");
    }

    scoreSummaryEl.textContent = data.score_summary || "";

    const ai = data.ai_insights;
    if (ai) {
      aiSourceBadge.textContent = ai.source && ai.source.includes("gemini")
        ? "✨ Live Gemini AI"
        : "🤖 Smart AI Engine";

      aiAppreciationText.textContent = ai.appreciation || "Thank you for completing this self-check!";

      // Key Observations
      observationsList.innerHTML = "";
      if (ai.key_observations && ai.key_observations.length > 0) {
        ai.key_observations.forEach((obs) => {
          const li = document.createElement("li");
          li.className = "obs-item";
          const isWarning = obs.toLowerCase().includes("deficit") || obs.toLowerCase().includes("strain") || obs.toLowerCase().includes("overload") || obs.toLowerCase().includes("stress");
          const icon = isWarning ? "⚠️" : "🌱";
          li.innerHTML = `<span class="obs-icon">${icon}</span><span>${obs}</span>`;
          observationsList.appendChild(li);
        });
      }

      // Action Plan Cards
      actionGrid.innerHTML = "";
      if (ai.action_plan && ai.action_plan.length > 0) {
        ai.action_plan.forEach((item) => {
          const card = document.createElement("div");
          card.className = "action-card";
          card.innerHTML = `
            <span class="action-category-tag">${item.category || "Action"}</span>
            <h5 class="action-title">${item.action}</h5>
            <p class="action-impact">${item.impact}</p>
            <div class="action-tip-box">
              <strong>💡 Micro-Habit:</strong> ${item.tip}
            </div>
          `;
          actionGrid.appendChild(card);
        });
      }

      // Encouragement
      aiEncouragementText.textContent = ai.encouragement || "Small daily rituals create monumental shifts in well-being.";
    }

    showState("result");
    animateScore(score);

    // Smooth scroll on mobile
    if (window.innerWidth <= 960) {
      document.getElementById("result-card")?.scrollIntoView({ behavior: "smooth" });
    }
  }

  // ---------------------------------------------------------
  // Copy Summary to Clipboard
  // ---------------------------------------------------------
  copySummaryBtn.addEventListener("click", () => {
    if (!currentResultData) return;
    const s = currentResultData;
    const ai = s.ai_insights || {};
    
    let text = `🧠 Mental Health Signal Assessment\n`;
    text += `Predicted Wellness Score: ${s.predicted_mental_health_score} / 10 (${s.score_category})\n\n`;
    text += `💖 Appreciation:\n${ai.appreciation || ""}\n\n`;
    text += `🎯 Recommended Action Plan:\n`;
    (ai.action_plan || []).forEach((item, idx) => {
      text += `${idx + 1}. [${item.category}] ${item.action}\n   Tip: ${item.tip}\n`;
    });
    text += `\n"${ai.encouragement || ""}"\n`;

    navigator.clipboard.writeText(text).then(() => {
      const origText = copySummaryBtn.textContent;
      copySummaryBtn.textContent = "✅ Copied to Clipboard!";
      setTimeout(() => (copySummaryBtn.textContent = origText), 2000);
    }).catch(() => {
      alert("Report copied!");
    });
  });

  // ---------------------------------------------------------
  // Submit Handler
  // ---------------------------------------------------------
  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    clearAllErrors();

    const payload = collectPayload();
    const clientErrors = validate(payload);

    if (clientErrors.length > 0) {
      clientErrors.forEach(([input, msg]) => input && setFieldError(input, msg));
      clientErrors[0][0]?.focus?.();
      return;
    }

    setSubmitting(true);
    showState("loading");

    try {
      const res = await fetch(`${API_BASE}/predict`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      if (!res.ok) {
        throw new Error(`Server returned status ${res.status}`);
      }

      const data = await res.json();
      renderResult(data);
    } catch (err) {
      console.error(err);
      const errorTitle = document.getElementById("error-title");
      const errorCopy = document.getElementById("error-copy");
      errorTitle.textContent = "Assessment Unavailable";
      errorCopy.textContent = "Could not reach the wellness model service. Please ensure the backend is running.";
      showState("error");
    } finally {
      setSubmitting(false);
    }
  });

  // ---------------------------------------------------------
  // Reset & Retry Handlers
  // ---------------------------------------------------------
  resetBtn.addEventListener("click", () => {
    showState("idle");
    gaugeFill.style.strokeDashoffset = GAUGE_CIRCUMFERENCE;
    scoreNumberEl.textContent = "0.0";
    form.scrollIntoView({ behavior: "smooth" });
  });

  errorRetryBtn.addEventListener("click", () => {
    showState("idle");
  });

})();
